"""PocketSmart AI package."""
